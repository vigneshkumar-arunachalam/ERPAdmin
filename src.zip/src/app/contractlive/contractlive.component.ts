import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contractlive',
  templateUrl: './contractlive.component.html',
  styleUrls: ['./contractlive.component.css']
})
export class ContractliveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
