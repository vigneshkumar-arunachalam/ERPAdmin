import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alert-check',
  templateUrl: './alert-check.component.html',
  styleUrls: ['./alert-check.component.css']
})
export class AlertCheckComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
